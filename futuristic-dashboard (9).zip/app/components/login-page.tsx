"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tv, User, Lock, ArrowLeft, Shield, Users, Headphones } from "lucide-react"

interface LoginPageProps {
  onLogin: (role: "manager" | "salesman" | "customer-service", userData: { name: string; username: string }) => void
  onBack: () => void
}

const SALES_USERS = [
  { id: 1, username: "8001", password: "2752004", name: "mohsen sayed" },
  { id: 2, username: "8002", password: "159753", name: "ahmed helmy" },
  { id: 3, username: "8003", password: "13579", name: "marawan khaled" },
  { id: 4, username: "8004", password: "2520", name: "shiref ashraf" },
  { id: 5, username: "8005", password: "2316", name: "ahmed hikal" },
  { id: 6, username: "8006", password: "777", name: "omar ramadan" },
  { id: 7, username: "8011", password: "392000", name: "sayed shiref" },
  { id: 8, username: "8013", password: "35422964", name: "khaled tarek" },
  { id: 9, username: "8014", password: "9528", name: "mohamed hossam" },
  { id: 10, username: "8015", password: "mn15", name: "mina nasr" },
  { id: 11, username: "8016", password: "292005bh", name: "beshoy hany" },
  { id: 12, username: "8018", password: "Manara1234", name: "yousef mohamed" },
  { id: 13, username: "8020", password: "20062001", name: "mohamed sayed" },
  { id: 14, username: "8021", password: "ko021", name: "kerolos montaser" },
  { id: 15, username: "8024", password: "2134", name: "mostafa shafey" },
  { id: 16, username: "8010", password: "ro1234", name: "rodaina" },
]

const MANAGER_USERS = [{ username: "manager", password: "admin123", name: "System Manager" }]

const SUPPORT_USERS = [{ username: "support", password: "support123", name: "Customer Support" }]

export default function LoginPage({ onLogin, onBack }: LoginPageProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [selectedRole, setSelectedRole] = useState<"manager" | "salesman" | "customer-service">("salesman")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [showDemo, setShowDemo] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const particles: Array<{
      x: number
      y: number
      vx: number
      vy: number
      size: number
      opacity: number
    }> = []

    for (let i = 0; i < 30; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.3 + 0.1,
      })
    }

    function animate() {
      if (!ctx || !canvas) return

      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((particle) => {
        particle.x += particle.vx
        particle.y += particle.vy

        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1

        ctx.beginPath()
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(34, 211, 238, ${particle.opacity})`
        ctx.fill()
      })

      requestAnimationFrame(animate)
    }

    animate()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    await new Promise((resolve) => setTimeout(resolve, 1500))

    let authenticatedUser = null

    // Validate credentials based on selected role
    if (selectedRole === "salesman") {
      authenticatedUser = SALES_USERS.find((user) => user.username === username && user.password === password)
    } else if (selectedRole === "manager") {
      authenticatedUser = MANAGER_USERS.find((user) => user.username === username && user.password === password)
    } else if (selectedRole === "customer-service") {
      authenticatedUser = SUPPORT_USERS.find((user) => user.username === username && user.password === password)
    }

    if (authenticatedUser) {
      const userData = {
        name: authenticatedUser.name,
        username: authenticatedUser.username,
      }
      onLogin(selectedRole, userData)
    } else {
      setError("Invalid username or password. Please check your credentials.")
    }

    setIsLoading(false)
  }

  return (
    <div className="min-h-screen dark bg-slate-950 transition-colors duration-300">
      <canvas
        ref={canvasRef}
        className="fixed inset-0 pointer-events-none z-0"
        style={{
          background: "radial-gradient(ellipse at center, rgba(15, 23, 42, 0.8) 0%, rgba(2, 6, 23, 1) 100%)",
        }}
      />

      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-4xl">
          {/* Header */}
          <div className="text-center mb-8">
            <Button
              variant="ghost"
              onClick={onBack}
              className="absolute top-4 left-4 text-slate-400 hover:text-slate-100"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>

            <div className="flex items-center justify-center space-x-2 mb-4">
              <Tv className="h-8 w-8 text-cyan-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                Vmax IPTV
              </span>
            </div>
            <h1 className="text-2xl font-bold text-slate-100 mb-2">Access Management System</h1>
            <p className="text-slate-400">Sign in to your account</p>
          </div>

          <div className="text-center mb-6">
            <Button
              variant="outline"
              onClick={() => setShowDemo(!showDemo)}
              className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border-purple-500/50 text-purple-400 hover:bg-purple-500/30"
            >
              {showDemo ? "Hide Demo Credentials" : "Show Demo Credentials"}
            </Button>
          </div>

          <div className="flex gap-6 items-start">
            {/* Login Form */}
            <div className="flex-1 max-w-md mx-auto">
              {/* Role Selection */}
              <div className="mb-6">
                <Label className="text-sm text-slate-400 mb-3 block">Select Your Role</Label>
                <div className="grid grid-cols-3 gap-2">
                  <RoleButton
                    icon={Shield}
                    label="Manager"
                    role="manager"
                    selected={selectedRole === "manager"}
                    onClick={() => setSelectedRole("manager")}
                  />
                  <RoleButton
                    icon={Users}
                    label="Salesman"
                    role="salesman"
                    selected={selectedRole === "salesman"}
                    onClick={() => setSelectedRole("salesman")}
                  />
                  <RoleButton
                    icon={Headphones}
                    label="Support"
                    role="customer-service"
                    selected={selectedRole === "customer-service"}
                    onClick={() => setSelectedRole("customer-service")}
                  />
                </div>
              </div>

              <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-slate-100 text-center">
                    {selectedRole === "manager"
                      ? "Manager Login"
                      : selectedRole === "salesman"
                        ? "Salesman Login"
                        : "Customer Service Login"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="username" className="text-slate-400">
                        Username
                      </Label>
                      <div className="relative">
                        <User className="absolute left-3 top-3 h-4 w-4 text-slate-500" />
                        <Input
                          id="username"
                          type="text"
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                          className="pl-10 bg-slate-800/50 border-slate-700 text-slate-100"
                          placeholder="Enter your username"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="password" className="text-slate-400">
                        Password
                      </Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-500" />
                        <Input
                          id="password"
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="pl-10 bg-slate-800/50 border-slate-700 text-slate-100"
                          placeholder="Enter your password"
                          required
                        />
                      </div>
                    </div>

                    {error && (
                      <div className="text-red-400 text-sm text-center bg-red-500/10 border border-red-500/20 rounded p-2">
                        {error}
                      </div>
                    )}

                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
                      disabled={isLoading}
                    >
                      {isLoading ? "Signing In..." : "Sign In"}
                    </Button>
                  </form>

                  <div className="mt-4 text-center">
                    <p className="text-xs text-slate-500">
                      {selectedRole === "salesman"
                        ? "Use your assigned sales credentials (8001-8024)"
                        : selectedRole === "manager"
                          ? "Manager: manager / admin123"
                          : "Support: support / support123"}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {showDemo && (
              <div className="flex-1 max-w-2xl">
                <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-slate-100 text-center flex items-center justify-center gap-2">
                      <Shield className="h-5 w-5 text-cyan-500" />
                      Demo Credentials
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Manager Credentials */}
                    <div>
                      <h3 className="text-lg font-semibold text-cyan-400 mb-3 flex items-center gap-2">
                        <Shield className="h-4 w-4" />
                        Manager Access
                      </h3>
                      <div className="bg-slate-800/50 rounded-lg p-3">
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div className="text-slate-400">Username</div>
                          <div className="text-slate-400">Password</div>
                          <div className="text-slate-400">Name</div>
                          <div className="text-slate-100 font-mono">manager</div>
                          <div className="text-slate-100 font-mono">admin123</div>
                          <div className="text-slate-100">System Manager</div>
                        </div>
                      </div>
                    </div>

                    {/* Customer Service Credentials */}
                    <div>
                      <h3 className="text-lg font-semibold text-green-400 mb-3 flex items-center gap-2">
                        <Headphones className="h-4 w-4" />
                        Customer Service Access
                      </h3>
                      <div className="bg-slate-800/50 rounded-lg p-3">
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div className="text-slate-400">Username</div>
                          <div className="text-slate-400">Password</div>
                          <div className="text-slate-400">Name</div>
                          <div className="text-slate-100 font-mono">support</div>
                          <div className="text-slate-100 font-mono">support123</div>
                          <div className="text-slate-100">Customer Support</div>
                        </div>
                      </div>
                    </div>

                    {/* Sales Team Credentials */}
                    <div>
                      <h3 className="text-lg font-semibold text-blue-400 mb-3 flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        Sales Team Access ({SALES_USERS.length} Members)
                      </h3>
                      <div className="bg-slate-800/50 rounded-lg p-3 max-h-80 overflow-y-auto">
                        <div className="grid grid-cols-4 gap-4 text-sm mb-2 pb-2 border-b border-slate-700">
                          <div className="text-slate-400 font-semibold">ID</div>
                          <div className="text-slate-400 font-semibold">Username</div>
                          <div className="text-slate-400 font-semibold">Password</div>
                          <div className="text-slate-400 font-semibold">Name</div>
                        </div>
                        {SALES_USERS.map((user) => (
                          <div
                            key={user.id}
                            className="grid grid-cols-4 gap-4 text-sm py-1 hover:bg-slate-700/30 rounded"
                          >
                            <div className="text-slate-300">{user.id}</div>
                            <div className="text-slate-100 font-mono">{user.username}</div>
                            <div className="text-slate-100 font-mono">{user.password}</div>
                            <div className="text-slate-100 capitalize">{user.name}</div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Quick Login Buttons */}
                    <div className="pt-4 border-t border-slate-700">
                      <h4 className="text-sm font-semibold text-slate-300 mb-3">Quick Login (Click to auto-fill)</h4>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setUsername("manager")
                            setPassword("admin123")
                            setSelectedRole("manager")
                          }}
                          className="text-xs bg-cyan-500/10 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/20"
                        >
                          Manager
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setUsername("support")
                            setPassword("support123")
                            setSelectedRole("customer-service")
                          }}
                          className="text-xs bg-green-500/10 border-green-500/30 text-green-400 hover:bg-green-500/20"
                        >
                          Support
                        </Button>
                        {SALES_USERS.slice(0, 6).map((user) => (
                          <Button
                            key={user.id}
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setUsername(user.username)
                              setPassword(user.password)
                              setSelectedRole("salesman")
                            }}
                            className="text-xs bg-blue-500/10 border-blue-500/30 text-blue-400 hover:bg-blue-500/20"
                          >
                            {user.name.split(" ")[0]}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function RoleButton({
  icon: Icon,
  label,
  role,
  selected,
  onClick,
}: {
  icon: any
  label: string
  role: string
  selected: boolean
  onClick: () => void
}) {
  return (
    <Button
      variant="outline"
      onClick={onClick}
      className={`h-16 flex flex-col items-center justify-center space-y-1 ${
        selected
          ? "bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border-cyan-500/50 text-cyan-400"
          : "border-slate-700 bg-slate-800/30 text-slate-400 hover:bg-slate-700/50"
      }`}
    >
      <Icon className="h-5 w-5" />
      <span className="text-xs">{label}</span>
    </Button>
  )
}
