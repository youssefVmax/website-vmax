"use client"

import { useState } from "react"
import { Bell, Plus, Send, Trash2, User, Clock, AlertCircle, CheckCircle, Info, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Notification {
  id: string
  title: string
  message: string
  type: "info" | "warning" | "success" | "error"
  priority: "low" | "medium" | "high"
  from: string
  to: string[]
  timestamp: Date
  read: boolean
  assignedBy?: string
}

interface NotificationsPageProps {
  userRole: "manager" | "salesman" | "customer-service"
  user?: { name: string; username: string } | null
}

export default function NotificationsPage({ userRole, user }: NotificationsPageProps) {
  const currentUser = user || { name: "Unknown User", username: "unknown" }

  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      title: "Monthly Sales Target Update",
      message: "Your monthly sales target has been updated to $25,000. Please review and confirm.",
      type: "info",
      priority: "high",
      from: "Manager",
      to: ["mohsen sayed", "ahmed helmy"],
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      read: false,
      assignedBy: "System Admin",
    },
    {
      id: "2",
      title: "Deal Approval Required",
      message: "TechCorp Solutions deal worth $15,000 requires manager approval.",
      type: "warning",
      priority: "high",
      from: "mohsen sayed",
      to: ["Manager"],
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      read: true,
      assignedBy: "mohsen sayed",
    },
    {
      id: "3",
      title: "Customer Service Alert",
      message: "Customer complaint received for StreamMax Ltd. Immediate attention required.",
      type: "error",
      priority: "high",
      from: "Customer Service",
      to: ["Manager", "ahmed helmy"],
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      read: false,
      assignedBy: "CS Team",
    },
    {
      id: "4",
      title: "Weekly Performance Report",
      message: "Your weekly performance report is ready for review. Great job this week!",
      type: "success",
      priority: "medium",
      from: "System",
      to: ["All Salesmen"],
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
      read: true,
      assignedBy: "System",
    },
  ])

  const [showCreateForm, setShowCreateForm] = useState(false)
  const [newNotification, setNewNotification] = useState({
    title: "",
    message: "",
    type: "info" as const,
    priority: "medium" as const,
    to: [] as string[],
  })

  const salesTeam = [
    "mohsen sayed",
    "ahmed helmy",
    "marawan khaled",
    "shiref ashraf",
    "ahmed hikal",
    "omar ramadan",
    "sayed shiref",
    "khaled tarek",
    "mohamed hossam",
    "mina nasr",
    "beshoy hany",
    "yousef mohamed",
    "mohamed sayed",
    "kerolos montaser",
    "mostafa shafey",
    "rodaina",
  ]

  const canCreateNotifications = userRole === "manager" || userRole === "customer-service"

  const handleCreateNotification = () => {
    if (!newNotification.title || !newNotification.message || newNotification.to.length === 0) return

    const notification: Notification = {
      id: Date.now().toString(),
      title: newNotification.title,
      message: newNotification.message,
      type: newNotification.type,
      priority: newNotification.priority,
      from: currentUser.name,
      to: newNotification.to,
      timestamp: new Date(),
      read: false,
      assignedBy: currentUser.name,
    }

    setNotifications((prev) => [notification, ...prev])
    setNewNotification({
      title: "",
      message: "",
      type: "info",
      priority: "medium",
      to: [],
    })
    setShowCreateForm(false)
  }

  const handleMarkAsRead = (id: string) => {
    setNotifications((prev) => prev.map((notif) => (notif.id === id ? { ...notif, read: true } : notif)))
  }

  const handleDeleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((notif) => notif.id !== id))
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-400" />
      case "warning":
        return <AlertCircle className="h-4 w-4 text-yellow-400" />
      case "error":
        return <AlertCircle className="h-4 w-4 text-red-400" />
      default:
        return <Info className="h-4 w-4 text-blue-400" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "border-red-500/50 bg-red-500/10"
      case "medium":
        return "border-yellow-500/50 bg-yellow-500/10"
      case "low":
        return "border-green-500/50 bg-green-500/10"
      default:
        return "border-slate-500/50 bg-slate-500/10"
    }
  }

  const filteredNotifications = notifications.filter((notif) => {
    if (userRole === "manager") return true
    if (userRole === "customer-service") return true
    return notif.to.includes(currentUser.name) || notif.to.includes("All Salesmen")
  })

  const unreadCount = filteredNotifications.filter((notif) => !notif.read).length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Bell className="h-6 w-6 text-cyan-500" />
          <div>
            <h1 className="text-2xl font-bold text-slate-100">Notifications</h1>
            <p className="text-slate-400">
              {unreadCount > 0 ? `${unreadCount} unread notifications` : "All notifications read"}
            </p>
          </div>
        </div>

        {canCreateNotifications && (
          <Button
            onClick={() => setShowCreateForm(true)}
            className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create Notification
          </Button>
        )}
      </div>

      {/* Create Notification Form */}
      {showCreateForm && canCreateNotifications && (
        <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-slate-100">Create New Notification</CardTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowCreateForm(false)}
              className="text-slate-400 hover:text-slate-100"
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Title</label>
                <Input
                  value={newNotification.title}
                  onChange={(e) => setNewNotification((prev) => ({ ...prev, title: e.target.value }))}
                  placeholder="Notification title..."
                  className="bg-slate-800/50 border-slate-700/50 text-slate-100"
                />
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Priority</label>
                <Select
                  value={newNotification.priority}
                  onValueChange={(value: "low" | "medium" | "high") =>
                    setNewNotification((prev) => ({ ...prev, priority: value }))
                  }
                >
                  <SelectTrigger className="bg-slate-800/50 border-slate-700/50 text-slate-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low Priority</SelectItem>
                    <SelectItem value="medium">Medium Priority</SelectItem>
                    <SelectItem value="high">High Priority</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Type</label>
                <Select
                  value={newNotification.type}
                  onValueChange={(value: "info" | "warning" | "success" | "error") =>
                    setNewNotification((prev) => ({ ...prev, type: value }))
                  }
                >
                  <SelectTrigger className="bg-slate-800/50 border-slate-700/50 text-slate-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="info">Information</SelectItem>
                    <SelectItem value="success">Success</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="error">Error</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Send To</label>
                <Select
                  value={newNotification.to.length > 0 ? newNotification.to[0] : ""}
                  onValueChange={(value) => setNewNotification((prev) => ({ ...prev, to: [value] }))}
                >
                  <SelectTrigger className="bg-slate-800/50 border-slate-700/50 text-slate-100">
                    <SelectValue placeholder="Select recipient..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All Salesmen">All Salesmen</SelectItem>
                    {salesTeam.map((salesman) => (
                      <SelectItem key={salesman} value={salesman}>
                        {salesman}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="text-sm text-slate-400 mb-2 block">Message</label>
              <Textarea
                value={newNotification.message}
                onChange={(e) => setNewNotification((prev) => ({ ...prev, message: e.target.value }))}
                placeholder="Enter your notification message..."
                className="bg-slate-800/50 border-slate-700/50 text-slate-100 min-h-[100px]"
              />
            </div>

            <div className="flex justify-end space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowCreateForm(false)}
                className="border-slate-700 text-slate-400 hover:text-slate-100"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateNotification}
                className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
              >
                <Send className="h-4 w-4 mr-2" />
                Send Notification
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Notifications List */}
      <div className="space-y-4">
        {filteredNotifications.length === 0 ? (
          <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
            <CardContent className="p-8 text-center">
              <Bell className="h-12 w-12 text-slate-600 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-400 mb-2">No notifications</h3>
              <p className="text-slate-500">You're all caught up! No new notifications to display.</p>
            </CardContent>
          </Card>
        ) : (
          filteredNotifications.map((notification) => (
            <Card
              key={notification.id}
              className={`bg-slate-900/50 border-slate-700/50 backdrop-blur-sm transition-all duration-200 hover:bg-slate-800/50 ${
                !notification.read ? getPriorityColor(notification.priority) : ""
              }`}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1">
                    <div className="mt-1">{getTypeIcon(notification.type)}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className={`font-medium ${!notification.read ? "text-slate-100" : "text-slate-300"}`}>
                          {notification.title}
                        </h3>
                        {!notification.read && <div className="h-2 w-2 bg-cyan-500 rounded-full animate-pulse"></div>}
                      </div>
                      <p className="text-slate-400 text-sm mb-2">{notification.message}</p>
                      <div className="flex items-center space-x-4 text-xs text-slate-500">
                        <div className="flex items-center space-x-1">
                          <User className="h-3 w-3" />
                          <span>From: {notification.from}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-3 w-3" />
                          <span>{notification.timestamp.toLocaleString()}</span>
                        </div>
                        <Badge
                          variant="outline"
                          className={`text-xs ${
                            notification.priority === "high"
                              ? "border-red-500/50 text-red-400"
                              : notification.priority === "medium"
                                ? "border-yellow-500/50 text-yellow-400"
                                : "border-green-500/50 text-green-400"
                          }`}
                        >
                          {notification.priority} priority
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    {!notification.read && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleMarkAsRead(notification.id)}
                        className="text-cyan-400 hover:text-cyan-300 text-xs"
                      >
                        Mark as read
                      </Button>
                    )}
                    {(canCreateNotifications || notification.to.includes(currentUser.name)) && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteNotification(notification.id)}
                        className="text-slate-400 hover:text-red-400 h-8 w-8"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
