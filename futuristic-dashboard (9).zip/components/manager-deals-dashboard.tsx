"use client"

import { useState, useEffect, useRef, useMemo, useCallback } from "react"
import { motion } from "framer-motion"
import Papa from "papaparse"
import {
  Filter,
  Sparkles,
  Diamond,
  TrendingUp,
  Users,
  DollarSign,
  Award,
  BarChart3,
  PieChart,
  Activity,
  Bell,
  Edit3,
  X,
} from "lucide-react"

const CSV_URL =
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/3%2C4%2C5%2C6%2C7-monthes_with_all_IDs-U2tDfI3EhWbqP1Znn3aTBVetS92sLM.csv"

function parseNumber(val: string | number): number {
  const num = Number(val)
  return isNaN(num) ? 0 : num
}

interface SalesRow {
  signup_date: string
  end_date: string
  Customer_Name: string
  email: string
  phone_number: string
  country: string
  amount_paid: number
  paid_per_month: number
  duration_months: number
  sales_agent: string
  closing_agent: string
  sales_team: string
  product_type: string
  service_tier: string
  data_month: string
  data_year: string
  invoice_link: string
  is_ibo_player: boolean
  is_bob_player: boolean
  is_smarters: boolean
  is_ibo_pro: boolean
  days_remaining: number
  paid_per_day: number
  duration_mean_paid: number
  agent_avg_paid: number
  is_above_avg: boolean
  paid_rank: number
  end_year: string
  sales_agent_norm: string
  closing_agent_norm: string
  SalesAgentID: string
  ClosingAgentID: string
  DealID: string
  Payment: string
}

function transformRow(row: any): SalesRow {
  // Payment method logic: if invoice_link starts with 'http', then it's 'PayPal', else it's 'Website'
  const paymentMethod =
    row.invoice_link && row.invoice_link.toString().toLowerCase().startsWith("http") ? "PayPal" : "Website"

  return {
    signup_date: row.signup_date || "",
    end_date: row.end_date || "",
    Customer_Name: row.Customer_Name || "",
    email: row.email || "",
    phone_number: row.phone_number || "",
    country: row.country || "",
    amount_paid: parseNumber(row.amount_paid),
    paid_per_month: parseNumber(row.paid_per_month),
    duration_months: parseNumber(row.duration_months),
    sales_agent: row.sales_agent || "",
    closing_agent: row.closing_agent || "",
    sales_team: row.sales_team || "",
    product_type: row.product_type || "",
    service_tier: row.service_tier || "",
    data_month: row.data_month || "",
    data_year: row.data_year || "",
    invoice_link: row.invoice_link || "",
    is_ibo_player: row.is_ibo_player === "TRUE",
    is_bob_player: row.is_bob_player === "TRUE",
    is_smarters: row.is_smarters === "TRUE",
    is_ibo_pro: row.is_ibo_pro === "TRUE",
    days_remaining: parseNumber(row.days_remaining),
    paid_per_day: parseNumber(row.paid_per_day),
    duration_mean_paid: parseNumber(row.duration_mean_paid),
    agent_avg_paid: parseNumber(row.agent_avg_paid),
    is_above_avg: row.is_above_avg === "TRUE",
    paid_rank: parseNumber(row.paid_rank),
    end_year: row.end_year || "",
    sales_agent_norm: row.sales_agent_norm || "",
    closing_agent_norm: row.closing_agent_norm || "",
    SalesAgentID: row.SalesAgentID || "",
    ClosingAgentID: row.ClosingAgentID || "",
    DealID: row.DealID || "",
    Payment: paymentMethod,
  }
}

const COLORS = [
  "#22D3EE", // cyan-400
  "#3B82F6", // blue-500
  "#8B5CF6", // violet-500
  "#10B981", // emerald-500
  "#F59E0B", // amber-500
  "#EF4444", // red-500
  "#EC4899", // pink-500
  "#14B8A6", // teal-500
  "#F97316", // orange-500
  "#84CC16", // lime-500
]

// Month ordering for proper arrangement
const MONTH_ORDER = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
]

interface SalesmanTarget {
  id: string
  name: string
  monthlyTarget: number
  currentRevenue: number
  dealsTarget: number
  currentDeals: number
  progress: number
  status: "on-track" | "behind" | "exceeded"
}

interface Notification {
  id: string
  type: "success" | "warning" | "info" | "error"
  title: string
  message: string
  timestamp: string
  read: boolean
  assignedTo?: string
  priority?: "low" | "medium" | "high"
}

export default function ManagerDealsDashboard() {
  const [salesData, setSalesData] = useState<SalesRow[]>([])
  const [filteredData, setFilteredData] = useState<SalesRow[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [loadingMessage, setLoadingMessage] = useState("Initializing...")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [filters, setFilters] = useState({
    Customer_Name: "",
    amount_paid: "",
    sales_agent: "",
    closing_agent: "",
    product_type: "",
    service_tier: "",
    sales_team: "",
    data_month: "",
    country: "",
    Payment: "",
    duration_months: "",
    end_year: "",
  })

  const [salesmanTargets, setSalesmanTargets] = useState<SalesmanTarget[]>([])
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [showNotifications, setShowNotifications] = useState(false)
  const [editingTarget, setEditingTarget] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<"overview" | "salesmen" | "notifications">("overview")

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const particles: Array<{
      x: number
      y: number
      vx: number
      vy: number
      size: number
      opacity: number
    }> = []

    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.1,
      })
    }

    function animate() {
      if (!ctx || !canvas) return

      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((particle, index) => {
        particle.x += particle.vx
        particle.y += particle.vy

        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1

        ctx.beginPath()
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(34, 211, 238, ${particle.opacity})`
        ctx.fill()

        // Draw connections
        particles.forEach((otherParticle, otherIndex) => {
          if (index !== otherIndex) {
            const dx = particle.x - otherParticle.x
            const dy = particle.y - otherParticle.y
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < 100) {
              ctx.beginPath()
              ctx.moveTo(particle.x, particle.y)
              ctx.lineTo(otherParticle.x, otherParticle.y)
              ctx.strokeStyle = `rgba(34, 211, 238, ${0.1 * (1 - distance / 100)})`
              ctx.lineWidth = 0.5
              ctx.stroke()
            }
          }
        })
      })

      requestAnimationFrame(animate)
    }

    animate()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  useEffect(() => {
    const loadCSVData = async () => {
      try {
        setLoading(true)
        setLoadingProgress(10)
        setLoadingMessage("Connecting to data source...")

        const response = await fetch(CSV_URL)
        setLoadingProgress(30)
        setLoadingMessage("Downloading sales data...")

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }

        const csvText = await response.text()
        setLoadingProgress(60)
        setLoadingMessage("Processing sales records...")

        Papa.parse(csvText, {
          header: true,
          skipEmptyLines: true,
          complete: (results: Papa.ParseResult<any>) => {
            setLoadingProgress(80)
            setLoadingMessage("Analyzing data...")

            const rows: SalesRow[] = results.data
              .map((row: any) => transformRow(row))
              .filter((row: SalesRow) => row.sales_agent && row.amount_paid > 0)

            setLoadingProgress(95)
            setLoadingMessage("Finalizing dashboard...")

            setSalesData(rows)
            setFilteredData(rows)

            setTimeout(() => {
              setLoadingProgress(100)
              setLoadingMessage("Complete!")
              setLoading(false)
            }, 500)
          },
          error: (error: any) => {
            console.error("CSV parsing error:", error)
            setSalesData([])
            setFilteredData([])
            setLoading(false)
          },
        })
      } catch (error) {
        console.error("Failed to load CSV data:", error)
        setSalesData([])
        setFilteredData([])
        setLoading(false)
      }
    }

    loadCSVData()
  }, [])

  const getUniqueValues = (field: keyof SalesRow): string[] => {
    if (!salesData || salesData.length === 0) return []

    let values: string[] = [
      ...new Set(
        salesData
          .map((item: SalesRow) => item[field]?.toString().trim())
          .filter((v: string | undefined): v is string => !!v && v !== "" && v !== "undefined" && v !== "null"),
      ),
    ]

    // Special handling for months - sort by actual month order
    if (field === "data_month") {
      values = values.sort((a, b) => {
        const indexA = MONTH_ORDER.indexOf(a)
        const indexB = MONTH_ORDER.indexOf(b)
        return indexA - indexB
      })
    } else {
      values = values.sort()
    }

    return values
  }

  useEffect(() => {
    let filtered = salesData

    Object.entries(filters).forEach(([key, value]) => {
      if (value) {
        if (key === "Customer_Name") {
          filtered = filtered.filter((item: SalesRow) =>
            item.Customer_Name?.toLowerCase().includes(value.toLowerCase()),
          )
        } else if (key === "product_type" && value === "Other") {
          // Get top 5 products
          const productRevenue: Record<string, number> = {}
          salesData.forEach((item) => {
            const product = item.product_type?.trim() || "Unknown"
            productRevenue[product] = (productRevenue[product] || 0) + item.amount_paid
          })
          const topProducts = Object.entries(productRevenue)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([name]) => name)

          filtered = filtered.filter((item: SalesRow) => !topProducts.includes(item.product_type?.trim() || "Unknown"))
        } else if (key === "Payment") {
          // Filter by payment method
          filtered = filtered.filter((item: SalesRow) => item.Payment === value)
        } else {
          filtered = filtered.filter((item: SalesRow) => String(item[key as keyof SalesRow])?.trim() === value)
        }
      }
    })

    setFilteredData(filtered)
  }, [filters, salesData])

  const analytics = useMemo(() => {
    const totalRevenue = filteredData.reduce((sum, item) => sum + item.amount_paid, 0)
    const totalDeals = filteredData.length
    const avgDealValue = filteredData.length > 0 ? totalRevenue / filteredData.length : 0

    // Agent performance calculation
    const agentRevenue: Record<string, number> = {}
    const agentDeals: Record<string, number> = {}
    filteredData.forEach((item) => {
      const agent = item.sales_agent?.trim() || "Unknown"
      agentRevenue[agent] = (agentRevenue[agent] || 0) + item.amount_paid
      agentDeals[agent] = (agentDeals[agent] || 0) + 1
    })

    const agentPerformance = Object.entries(agentRevenue)
      .map(([agent, revenue]) => [agent, { revenue, deals: agentDeals[agent] || 0 }] as const)
      .sort((a, b) => b[1].revenue - a[1].revenue)

    // Product performance calculation
    const productRevenue: Record<string, number> = {}
    filteredData.forEach((item) => {
      const product = item.product_type?.trim() || "Unknown"
      productRevenue[product] = (productRevenue[product] || 0) + item.amount_paid
    })

    const productPerformance = Object.entries(productRevenue)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)

    // Monthly trends calculation
    const monthlyRevenue: Record<string, number> = {}
    filteredData.forEach((item) => {
      const month = item.data_month?.trim() || "Unknown"
      monthlyRevenue[month] = (monthlyRevenue[month] || 0) + item.amount_paid
    })

    const monthlyTrends = MONTH_ORDER.map((month) => ({
      month,
      revenue: monthlyRevenue[month] || 0,
    }))

    return {
      totalRevenue,
      totalDeals,
      avgDealValue,
      agentPerformance,
      productPerformance,
      monthlyTrends,
    }
  }, [filteredData])

  const updateSalesmanTargets = useCallback(() => {
    if (salesData.length > 0 && analytics.agentPerformance.length > 0) {
      const salesmanData = analytics.agentPerformance.map(([agent, data], index) => {
        const currentMonth = new Date().getMonth()
        const monthlyRevenue = filteredData
          .filter((item) => item.sales_agent === agent && new Date(item.signup_date).getMonth() === currentMonth)
          .reduce((sum, item) => sum + item.amount_paid, 0)

        const monthlyDeals = filteredData.filter(
          (item) => item.sales_agent === agent && new Date(item.signup_date).getMonth() === currentMonth,
        ).length

        // Default targets (can be customized)
        const monthlyTarget = 5000 + index * 1000 // Varying targets
        const dealsTarget = 10 + index * 2
        const progress = monthlyTarget > 0 ? (monthlyRevenue / monthlyTarget) * 100 : 0

        let status: "on-track" | "behind" | "exceeded" = "on-track"
        if (progress < 70) status = "behind"
        else if (progress > 100) status = "exceeded"

        return {
          id: `agent-${index}`,
          name: agent,
          monthlyTarget,
          currentRevenue: monthlyRevenue,
          dealsTarget,
          currentDeals: monthlyDeals,
          progress: Math.min(progress, 150), // Cap at 150%
          status,
        }
      })

      setSalesmanTargets(salesmanData)

      // Generate notifications based on performance
      const newNotifications: Notification[] = []
      salesmanData.forEach((salesman) => {
        if (salesman.status === "exceeded") {
          newNotifications.push({
            id: `notif-${salesman.id}-exceeded`,
            type: "success",
            title: "Target Exceeded!",
            message: `${salesman.name} has exceeded their monthly target by ${(salesman.progress - 100).toFixed(1)}%`,
            timestamp: new Date().toISOString(),
            read: false,
            assignedTo: salesman.name,
            priority: "medium",
          })
        } else if (salesman.status === "behind") {
          newNotifications.push({
            id: `notif-${salesman.id}-behind`,
            type: "warning",
            title: "Behind Target",
            message: `${salesman.name} is ${(100 - salesman.progress).toFixed(1)}% behind their monthly target`,
            timestamp: new Date().toISOString(),
            read: false,
            assignedTo: salesman.name,
            priority: "high",
          })
        }
      })

      setNotifications(newNotifications)
    }
  }, [salesData, analytics.agentPerformance, filteredData])

  useEffect(() => {
    updateSalesmanTargets()
  }, [salesData.length]) // Only depend on salesData length, not the entire filteredData

  const handleTargetEdit = (salesmanId: string, field: "monthlyTarget" | "dealsTarget", value: number) => {
    setSalesmanTargets((prev) =>
      prev.map((salesman) =>
        salesman.id === salesmanId
          ? {
              ...salesman,
              [field]: value,
              progress: field === "monthlyTarget" ? (salesman.currentRevenue / value) * 100 : salesman.progress,
            }
          : salesman,
      ),
    )
  }

  const unreadNotifications = notifications.filter((n) => !n.read).length

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 relative overflow-hidden">
        <canvas
          ref={canvasRef}
          className="fixed inset-0 pointer-events-none z-0"
          style={{
            background: "radial-gradient(ellipse at center, rgba(15, 23, 42, 0.8) 0%, rgba(2, 6, 23, 1) 100%)",
          }}
        />

        <div className="text-center relative z-10 max-w-md mx-auto px-6">
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="relative mb-8"
          >
            <div className="w-24 h-24 border-4 border-slate-700 rounded-full mx-auto relative">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                className="absolute inset-0 border-4 border-transparent border-t-cyan-500 border-r-cyan-400 rounded-full"
              />
              <div className="absolute inset-4 bg-slate-800/50 rounded-full flex items-center justify-center backdrop-blur-sm">
                <BarChart3 className="w-8 h-8 text-cyan-400" />
              </div>
            </div>
          </motion.div>

          <motion.h2
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-2xl font-bold text-slate-100 mb-2"
          >
            Loading Manager Dashboard
          </motion.h2>

          <motion.p
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-slate-400 mb-6"
          >
            {loadingMessage}
          </motion.p>

          {/* Progress bar */}
          <motion.div
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: "100%", opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="w-full bg-slate-800 rounded-full h-2 mb-4 overflow-hidden"
          >
            <motion.div
              className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full relative"
              style={{ width: `${loadingProgress}%` }}
              transition={{ duration: 0.5, ease: "easeOut" }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse" />
            </motion.div>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-sm text-slate-500"
          >
            {loadingProgress}% Complete
          </motion.p>
        </div>
      </div>
    )
  }

  if (!loading && salesData.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <canvas
          ref={canvasRef}
          className="fixed inset-0 pointer-events-none z-0"
          style={{
            background: "radial-gradient(ellipse at center, rgba(15, 23, 42, 0.8) 0%, rgba(2, 6, 23, 1) 100%)",
          }}
        />
        <div className="text-center max-w-md relative z-10">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
            className="w-20 h-20 bg-slate-800/50 rounded-full flex items-center justify-center mx-auto mb-6 border border-slate-700"
          >
            <BarChart3 className="w-10 h-10 text-slate-400" />
          </motion.div>
          <h2 className="text-3xl font-bold text-slate-100 mb-4">No Sales Data Available</h2>
          <p className="text-slate-400 mb-6">
            The sales dashboard is ready, but no data has been loaded yet. Please ensure your CSV data source is
            accessible.
          </p>
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <p className="text-sm text-slate-500 mb-2">Expected data source:</p>
            <p className="text-xs text-cyan-400 font-mono break-all">{CSV_URL}</p>
          </div>
          <button
            onClick={() => window.location.reload()}
            className="mt-6 px-6 py-3 bg-cyan-500 hover:bg-cyan-600 text-white rounded-xl font-semibold transition-colors duration-200"
          >
            Retry Loading Data
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-950 transition-colors duration-300">
      <canvas
        ref={canvasRef}
        className="fixed inset-0 pointer-events-none z-0"
        style={{
          background: "radial-gradient(ellipse at center, rgba(15, 23, 42, 0.8) 0%, rgba(2, 6, 23, 1) 100%)",
        }}
      />

      <div className="p-6 space-y-8 relative z-10">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <motion.div
              animate={{ scale: [1, 1.2, 1], rotate: [0, 180, 360] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
            >
              <Sparkles className="w-8 h-8 text-cyan-500" />
            </motion.div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Manager Control Center
            </h1>
            <motion.div
              animate={{ scale: [1, 1.2, 1], rotate: [0, 180, 360] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
            >
              <Diamond className="w-8 h-8 text-blue-500" />
            </motion.div>
          </div>
          <p className="text-xl text-slate-400 mb-6">Complete sales team management and analytics platform</p>

          {/* Navigation Tabs */}
          <div className="flex justify-center space-x-4 mb-6">
            {[
              { id: "overview", label: "Overview", icon: BarChart3 },
              { id: "salesmen", label: "Sales Team", icon: Users },
              { id: "notifications", label: "Notifications", icon: Bell },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-semibold transition-all duration-200 ${
                  activeTab === tab.id
                    ? "bg-cyan-500 text-white shadow-lg"
                    : "bg-slate-800/50 text-slate-300 hover:bg-slate-700/50"
                }`}
              >
                <tab.icon className="w-5 h-5" />
                <span>{tab.label}</span>
                {tab.id === "notifications" && unreadNotifications > 0 && (
                  <span className="bg-red-500 text-white text-xs rounded-full px-2 py-1 min-w-[20px] h-5 flex items-center justify-center">
                    {unreadNotifications}
                  </span>
                )}
              </button>
            ))}
          </div>
        </motion.div>

        {activeTab === "overview" && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm rounded-3xl p-8 shadow-xl border"
            >
              <div className="flex items-center space-x-3 mb-6">
                <Filter className="w-6 h-6 text-cyan-500" />
                <h3 className="text-2xl font-bold text-slate-100">Smart Filters</h3>
                <span className="text-sm text-slate-500">Advanced deal filtering system</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
                {Object.entries(filters).map(([key, value]) => (
                  <div key={key} className="space-y-2">
                    <label className="block text-sm font-semibold text-slate-300 capitalize">
                      {key.replace(/([A-Z])/g, " $1").replace(/_/g, " ")}
                    </label>
                    {key === "Customer_Name" ? (
                      <input
                        type="text"
                        value={value}
                        onChange={(e) => setFilters((prev: typeof filters) => ({ ...prev, [key]: e.target.value }))}
                        placeholder="Type customer name..."
                        className="w-full px-4 py-3 border border-slate-600 rounded-xl bg-slate-800/50 text-slate-100 focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all duration-200 shadow-sm hover:shadow-md backdrop-blur-sm"
                      />
                    ) : (
                      <select
                        value={value}
                        onChange={(e) => setFilters((prev: typeof filters) => ({ ...prev, [key]: e.target.value }))}
                        className="w-full px-4 py-3 border border-slate-600 rounded-xl bg-slate-800/50 text-slate-100 focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all duration-200 shadow-sm hover:shadow-md backdrop-blur-sm"
                      >
                        <option value="">All {key.replace(/([A-Z])/g, " $1").replace(/_/g, " ")}</option>
                        {getUniqueValues(key as keyof SalesRow).map((option: string) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
            >
              {[
                {
                  icon: DollarSign,
                  label: "Total Revenue",
                  value: `$${analytics.totalRevenue.toLocaleString()}`,
                  color: "from-green-400 to-emerald-500",
                },
                {
                  icon: BarChart3,
                  label: "Total Deals",
                  value: analytics.totalDeals.toLocaleString(),
                  color: "from-blue-400 to-cyan-500",
                },
                {
                  icon: TrendingUp,
                  label: "Avg Deal Value",
                  value: `$${analytics.avgDealValue.toFixed(0)}`,
                  color: "from-purple-400 to-violet-500",
                },
                {
                  icon: Users,
                  label: "Active Agents",
                  value: analytics.agentPerformance.length.toString(),
                  color: "from-orange-400 to-red-500",
                },
              ].map((kpi, index) => (
                <motion.div
                  key={kpi.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm rounded-2xl p-6 shadow-xl border hover:shadow-2xl transition-all duration-300"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-r ${kpi.color} shadow-lg`}>
                      <kpi.icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-slate-100">{kpi.value}</p>
                      <p className="text-sm text-slate-400">{kpi.label}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm rounded-3xl p-8 shadow-xl border"
            >
              <div className="flex items-center space-x-3 mb-6">
                <Activity className="w-6 h-6 text-cyan-500" />
                <h3 className="text-2xl font-bold text-slate-100">Revenue Trends by Month</h3>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {analytics.monthlyTrends.map((monthData) => {
                  const revenue = monthData.revenue
                  const maxRevenue = Math.max(...analytics.monthlyTrends.map((mt) => mt.revenue))
                  const percentage = maxRevenue > 0 ? (revenue / maxRevenue) * 100 : 0

                  return (
                    <div key={monthData.month} className="text-center">
                      <div className="mb-2">
                        <div className="h-32 bg-slate-800 rounded-lg flex items-end p-2">
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: `${percentage}%` }}
                            transition={{ delay: 0.6, duration: 0.8 }}
                            className="w-full bg-gradient-to-t from-cyan-500 to-blue-400 rounded"
                          />
                        </div>
                      </div>
                      <p className="text-xs text-slate-400 mb-1">{monthData.month.slice(0, 3)}</p>
                      <p className="text-sm font-semibold text-slate-200">${revenue.toLocaleString()}</p>
                    </div>
                  )
                })}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm rounded-3xl p-8 shadow-xl border"
            >
              <div className="flex items-center space-x-3 mb-6">
                <Award className="w-6 h-6 text-yellow-500" />
                <h3 className="text-2xl font-bold text-slate-100">Top Performing Sales Agents</h3>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {analytics.agentPerformance.map(([agent, data], index) => (
                  <motion.div
                    key={agent}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.7 + index * 0.1 }}
                    className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700/50"
                  >
                    <div className="flex items-center space-x-4">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
                          index === 0
                            ? "bg-yellow-500"
                            : index === 1
                              ? "bg-gray-400"
                              : index === 2
                                ? "bg-amber-600"
                                : "bg-slate-600"
                        }`}
                      >
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-100">{agent}</p>
                        <p className="text-sm text-slate-400">{data.deals} deals</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-green-400">${data.revenue.toLocaleString()}</p>
                      <p className="text-sm text-slate-400">${(data.revenue / data.deals).toFixed(0)} avg</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm rounded-3xl p-8 shadow-xl border"
            >
              <div className="flex items-center space-x-3 mb-6">
                <PieChart className="w-6 h-6 text-purple-500" />
                <h3 className="text-2xl font-bold text-slate-100">Product Performance Analysis</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {analytics.productPerformance.map(([product, revenue], index) => {
                  const maxRevenue = analytics.productPerformance[0][1]
                  const percentage = (revenue / maxRevenue) * 100

                  return (
                    <motion.div
                      key={product}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.8 + index * 0.1, duration: 0.8 }}
                      className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-semibold text-slate-100 truncate">{product}</h4>
                        <span className="text-sm text-slate-400">#{index + 1}</span>
                      </div>
                      <div className="mb-2">
                        <div className="w-full bg-slate-700 rounded-full h-2">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${percentage}%` }}
                            transition={{ delay: 0.9 + index * 0.1, duration: 0.8 }}
                            className="h-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                          />
                        </div>
                      </div>
                      <p className="text-lg font-bold text-slate-100">${revenue.toLocaleString()}</p>
                    </motion.div>
                  )
                })}
              </div>
            </motion.div>
          </>
        )}

        {activeTab === "salesmen" && (
          <div className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm rounded-3xl p-8 shadow-xl border">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <Users className="w-6 h-6 text-blue-500" />
                <h3 className="text-2xl font-bold text-slate-100">Sales Team Management</h3>
              </div>
              <div className="text-sm text-slate-400">{salesmanTargets.length} active salesmen</div>
            </div>

            <div className="space-y-6">
              {salesmanTargets.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <h4 className="text-xl font-semibold text-slate-300 mb-2">No Sales Team Data</h4>
                  <p className="text-slate-500">Sales team information will appear here once data is loaded.</p>
                </div>
              ) : (
                salesmanTargets.map((salesman) => (
                  <motion.div
                    key={salesman.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className="p-6 bg-slate-800/50 rounded-xl border border-slate-700/50 hover:border-slate-600/50 transition-all duration-200"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-4">
                        <div
                          className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold ${
                            salesman.status === "exceeded"
                              ? "bg-green-500"
                              : salesman.status === "behind"
                                ? "bg-red-500"
                                : "bg-blue-500"
                          }`}
                        >
                          {salesman.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                            .toUpperCase()}
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-slate-100">{salesman.name}</h4>
                          <p className="text-sm text-slate-400 capitalize">{salesman.status.replace("-", " ")}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => setEditingTarget(editingTarget === salesman.id ? null : salesman.id)}
                        className="p-2 text-slate-400 hover:text-cyan-400 transition-colors duration-200"
                      >
                        {editingTarget === salesman.id ? <X className="w-5 h-5" /> : <Edit3 className="w-5 h-5" />}
                      </button>
                    </div>

                    {/* Progress Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between text-sm text-slate-400 mb-2">
                        <span>Progress</span>
                        <span>{salesman.progress.toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-slate-700 rounded-full h-3">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${Math.min(salesman.progress, 100)}%` }}
                          transition={{ duration: 0.8 }}
                          className={`h-3 rounded-full ${
                            salesman.status === "exceeded"
                              ? "bg-gradient-to-r from-green-500 to-emerald-400"
                              : salesman.status === "behind"
                                ? "bg-gradient-to-r from-red-500 to-orange-400"
                                : "bg-gradient-to-r from-blue-500 to-cyan-400"
                          }`}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="text-center p-4 bg-slate-900/50 rounded-lg">
                        <p className="text-2xl font-bold text-green-400">${salesman.currentRevenue.toLocaleString()}</p>
                        <p className="text-sm text-slate-400">Current Revenue</p>
                      </div>
                      <div className="text-center p-4 bg-slate-900/50 rounded-lg">
                        {editingTarget === salesman.id ? (
                          <input
                            type="number"
                            value={salesman.monthlyTarget}
                            onChange={(e) => handleTargetEdit(salesman.id, "monthlyTarget", Number(e.target.value))}
                            className="w-full text-center text-2xl font-bold bg-transparent text-blue-400 border-b border-blue-400 focus:outline-none"
                          />
                        ) : (
                          <p className="text-2xl font-bold text-blue-400">${salesman.monthlyTarget.toLocaleString()}</p>
                        )}
                        <p className="text-sm text-slate-400">Monthly Target</p>
                      </div>
                      <div className="text-center p-4 bg-slate-900/50 rounded-lg">
                        <p className="text-2xl font-bold text-purple-400">{salesman.currentDeals}</p>
                        <p className="text-sm text-slate-400">Current Deals</p>
                      </div>
                      <div className="text-center p-4 bg-slate-900/50 rounded-lg">
                        {editingTarget === salesman.id ? (
                          <input
                            type="number"
                            value={salesman.dealsTarget}
                            onChange={(e) => handleTargetEdit(salesman.id, "dealsTarget", Number(e.target.value))}
                            className="w-full text-center text-2xl font-bold bg-transparent text-orange-400 border-b border-orange-400 focus:outline-none"
                          />
                        ) : (
                          <p className="text-2xl font-bold text-orange-400">{salesman.dealsTarget}</p>
                        )}
                        <p className="text-sm text-slate-400">Deals Target</p>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === "notifications" && (
          <div className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm rounded-3xl p-8 shadow-xl border">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <Bell className="w-6 h-6 text-yellow-500" />
                <h3 className="text-2xl font-bold text-slate-100">Team Notifications</h3>
              </div>
              <div className="text-sm text-slate-400">{unreadNotifications} unread</div>
            </div>

            <div className="space-y-4">
              {notifications.length === 0 ? (
                <div className="text-center py-12">
                  <Bell className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <h4 className="text-xl font-semibold text-slate-300 mb-2">No Notifications</h4>
                  <p className="text-slate-500">Team performance notifications will appear here.</p>
                </div>
              ) : (
                notifications.map((notification) => (
                  <motion.div
                    key={notification.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={`p-4 rounded-xl border ${
                      notification.type === "success"
                        ? "bg-green-900/20 border-green-500/30"
                        : notification.type === "warning"
                          ? "bg-yellow-900/20 border-yellow-500/30"
                          : notification.type === "error"
                            ? "bg-red-900/20 border-red-500/30"
                            : "bg-blue-900/20 border-blue-500/30"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-slate-100 mb-1">{notification.title}</h4>
                        <p className="text-slate-300 mb-2">{notification.message}</p>
                        <div className="flex items-center space-x-4 text-sm text-slate-400">
                          <span>Assigned to: {notification.assignedTo}</span>
                          <span>Priority: {notification.priority}</span>
                          <span>{new Date(notification.timestamp).toLocaleString()}</span>
                        </div>
                      </div>
                      <div
                        className={`w-3 h-3 rounded-full ${
                          notification.type === "success"
                            ? "bg-green-500"
                            : notification.type === "warning"
                              ? "bg-yellow-500"
                              : notification.type === "error"
                                ? "bg-red-500"
                                : "bg-blue-500"
                        }`}
                      />
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
